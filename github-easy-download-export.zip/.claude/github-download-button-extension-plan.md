# GitHub Easy Download - Chrome Extension Plan

## Project Overview

A Chrome extension that adds a "Download" button to GitHub repository pages, automatically detecting the user's OS/architecture and matching the most appropriate release asset for one-click download.

### Problem Statement
Regular users unfamiliar with GitHub find it difficult to locate and download the correct release binary for their system. They must navigate to the Releases page, understand versioning, and manually identify which asset matches their OS and architecture.

### Solution
Inject a prominent "Download" button directly on the repository homepage that:
1. Automatically detects the user's operating system and CPU architecture
2. Fetches the latest release via GitHub's public API
3. Uses heuristics to match the best asset for the user's system
4. Provides one-click download with fallback options

---

## Decisions Made

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Page scope | Repository homepage only | Keeps scope focused; main page is where users land |
| Pre-releases | Ignore by default, toggle in options | Most users want stable releases |
| Authentication | Unauthenticated API calls | Simplicity; 60 req/hour is sufficient for normal use |
| No-match fallback | Auto-open releases page | Better than showing confusing dropdown of unknown assets |
| Button placement | Both top (near Code button) AND sidebar | Maximum discoverability |
| Old release warning | Subtle indicator if >1 year old | Helps users recognize potentially abandoned projects |
| Architecture | Background service worker with caching | Better rate limit management, improved performance |

---

## Technical Architecture

### Extension Components

```
github-easy-download/
├── manifest.json           # Extension manifest (MV3)
├── background.js           # Service worker for API calls + caching
├── content.js              # DOM injection and UI logic
├── content.css             # Styles for injected elements
├── popup/
│   ├── popup.html          # Extension popup UI
│   ├── popup.js            # Popup logic
│   └── popup.css           # Popup styles
├── options/
│   ├── options.html        # Options page
│   ├── options.js          # Options logic
│   └── options.css         # Options styles
├── lib/
│   ├── os-detect.js        # OS/architecture detection utilities
│   ├── asset-matcher.js    # Release asset matching logic
│   └── github-api.js       # GitHub API wrapper
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

### Data Flow

```
[User visits github.com/owner/repo]
        │
        ▼
[content.js detects repo page]
        │
        ▼
[content.js requests release data from background.js]
        │
        ▼
[background.js checks cache]
        │
        ├─► [Cache hit + fresh] ──► Return cached data
        │
        └─► [Cache miss/stale] ──► Fetch from GitHub API
                                         │
                                         ▼
                                   [Cache response (5-15 min TTL)]
                                         │
                                         ▼
                                   [Return to content.js]
        │
        ▼
[content.js runs asset matching with OS detection]
        │
        ▼
[Inject Download button(s) into DOM]
```

---

## OS and Architecture Detection

### Detection Strategy

```javascript
// Primary: High-entropy User-Agent Client Hints (modern browsers)
navigator.userAgentData.getHighEntropyValues([
  'platform',           // "Windows", "macOS", "Linux"
  'platformVersion',    // OS version
  'architecture',       // "x86", "arm"
  'bitness'            // "64", "32"
])

// Fallback: User-Agent string parsing
navigator.userAgent
navigator.platform
```

### Platform Identification

| Platform | Detection Signals |
|----------|-------------------|
| Windows | `platform === "Windows"` or UA contains `Windows NT` |
| macOS | `platform === "macOS"` or UA contains `Macintosh` |
| Linux | `platform === "Linux"` or UA contains `Linux` (exclude Android) |

### Architecture Identification

| Architecture | Detection Signals |
|--------------|-------------------|
| x64 (Intel/AMD) | `architecture === "x86"` + `bitness === "64"`, or UA contains `x86_64`, `Win64`, `WOW64` |
| ARM64 | `architecture === "arm"`, or UA contains `aarch64`, `arm64` |
| x86 (32-bit) | `bitness === "32"` or explicit `i386`, `i686` |

### Apple Silicon Challenge
- Some browsers report `x86` on Apple Silicon due to Rosetta 2 translation
- Mitigation: If macOS + uncertain architecture, prefer `universal` or `arm64` builds when available, otherwise fall back to x64 (Rosetta compatible)

---

## Asset Matching Algorithm

### Priority Matrix by OS

#### Windows
| Priority | Extension | Filename Keywords |
|----------|-----------|-------------------|
| 1 | `.exe` | `setup`, `installer`, `win`, `windows` |
| 2 | `.msi` | `win`, `windows` |
| 3 | `.zip` | Must contain `win` or `windows` |

#### macOS  
| Priority | Extension | Filename Keywords |
|----------|-----------|-------------------|
| 1 | `.dmg` | `mac`, `macos`, `darwin`, `osx` |
| 2 | `.pkg` | `mac`, `macos`, `darwin`, `osx` |
| 3 | `.zip` | Must contain `mac`, `macos`, `darwin` |

#### Linux
| Priority | Extension | Filename Keywords |
|----------|-----------|-------------------|
| 1 | `.AppImage` | `linux` |
| 2 | `.deb` | `linux`, `ubuntu`, `debian` |
| 3 | `.rpm` | `linux`, `fedora`, `rhel`, `centos` |
| 4 | `.tar.gz`, `.tar.xz` | `linux` |

### Architecture Keywords to Match in Filenames

| Architecture | Keywords to Match |
|--------------|-------------------|
| x64 | `x64`, `x86_64`, `amd64`, `64bit`, `64-bit` |
| ARM64 | `arm64`, `aarch64`, `arm`, `apple-silicon`, `universal` |
| x86 (32-bit) | `x86`, `i386`, `i686`, `32bit`, `32-bit` |

### Scoring System

Rather than strict priority ordering, use a scoring system to handle edge cases:

```javascript
function scoreAsset(asset, userOS, userArch) {
  let score = 0;
  const name = asset.name.toLowerCase();
  
  // Extension score (highest weight)
  score += getExtensionScore(name, userOS);  // 0-100
  
  // OS keyword match
  score += getOSKeywordScore(name, userOS);  // 0-50
  
  // Architecture match
  score += getArchScore(name, userArch);      // 0-30
  
  // Architecture mismatch penalty
  score += getArchMismatchPenalty(name, userArch);  // -50 to 0
  
  return score;
}
```

### Negative Matching (Exclusions)
Avoid assets that explicitly target a different OS/arch:
- If user is on Windows, penalize assets containing `mac`, `darwin`, `linux`
- If user is on x64, penalize assets containing `arm64` (unless no x64 alternative)
- Skip assets that are clearly source archives: `source`, `src`, `.tar.gz` without OS keywords

---

## UI/UX Specifications

### Button Placement 1: Header Area (Primary)

Location: To the right of the green "Code" button in the repository header.

```
[Watch ▾] [Fork] [Star ⭐]                    [Code ▾] [⬇ Download v1.2.3]
```

Styling:
- Match GitHub's button aesthetic (border-radius, padding, font)
- Use a distinct but not jarring color (suggest: GitHub's blue accent `#0969da` or subtle green)
- Include download icon (↓ or GitHub's download octicon)
- Show version number in button text

### Button Placement 2: Sidebar (Secondary)

Location: In the right sidebar, near the existing "Releases" section.

```
┌─────────────────────────┐
│ Releases                │
│ v1.2.3 Latest           │
│ [⬇ Download for macOS]  │  ← Injected button
│ + 3 releases            │
└─────────────────────────┘
```

Styling:
- Smaller, more subtle than header button
- Include OS name for clarity: "Download for Windows", "Download for macOS"

### Button States

| State | Appearance | Behavior |
|-------|------------|----------|
| Loading | Spinner or skeleton | Disable click |
| Ready | "⬇ Download v1.2.3" | Click initiates download |
| No match | "View Releases →" | Click opens releases page |
| No releases | Hidden (don't show button) | — |
| Error | Hidden or "Releases" link | Fail gracefully |
| Old release (>1 year) | Normal + subtle warning icon/tooltip | Show tooltip: "Last updated X months ago" |

### Dropdown for Alternatives

When user clicks a small chevron/arrow next to the main button:
- Show detected OS/arch at top: "Detected: macOS (Apple Silicon)"
- List top 3-5 matching assets
- "View all releases" link at bottom

### Old Release Warning

If the release is older than 365 days:
- Add subtle visual indicator (⚠️ icon or muted color)
- Tooltip on hover: "This release is over 1 year old (released Mon DD, YYYY)"
- Do not block download, just inform

---

## GitHub API Integration

### Endpoint

```
GET https://api.github.com/repos/{owner}/{repo}/releases/latest
```

### Response Structure (Relevant Fields)

```json
{
  "tag_name": "v1.2.3",
  "name": "Release 1.2.3",
  "published_at": "2024-01-15T10:30:00Z",
  "prerelease": false,
  "assets": [
    {
      "name": "app-windows-x64.exe",
      "browser_download_url": "https://github.com/.../app-windows-x64.exe",
      "size": 52428800,
      "download_count": 1234,
      "content_type": "application/octet-stream"
    }
  ]
}
```

### Handling Pre-releases

Default behavior: Use `/releases/latest` which excludes pre-releases.

When "include pre-releases" option is enabled:
```
GET https://api.github.com/repos/{owner}/{repo}/releases
```
Then take `releases[0]` (most recent, may be pre-release).

### Rate Limiting

- Unauthenticated: 60 requests/hour per IP
- Mitigation: Cache responses in service worker (5-15 minute TTL)
- If rate limited (HTTP 403 with `X-RateLimit-Remaining: 0`):
  - Show cached data if available (even if stale)
  - Otherwise, show "View Releases" fallback button
  - Do not spam retries

### Error Handling

| HTTP Status | Meaning | Action |
|-------------|---------|--------|
| 200 | Success | Process response |
| 404 | No releases OR private repo | Hide button |
| 403 | Rate limited | Use cache or show fallback |
| 5xx | GitHub server error | Use cache or show fallback |

---

## Caching Strategy

### Storage

Use `chrome.storage.local` for persistence across browser sessions:

```javascript
{
  "cache_owner/repo": {
    "data": { /* release data */ },
    "timestamp": 1703001234567,
    "ttl": 900000  // 15 minutes in ms
  }
}
```

### Cache Invalidation

- TTL-based: Refresh if cached data is older than 15 minutes
- Manual: User can force refresh via popup
- Stale-while-revalidate: Show cached data immediately, fetch fresh in background

---

## Options/Settings

### Available Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `includePrereleases` | boolean | `false` | Whether to consider pre-release versions |
| `showOldReleaseWarning` | boolean | `true` | Show warning for releases >1 year old |
| `oldReleaseThresholdDays` | number | `365` | Days threshold for "old" warning |
| `cacheTTLMinutes` | number | `15` | How long to cache API responses |

### Storage

Use `chrome.storage.sync` for settings (syncs across user's Chrome instances).

---

## Content Script Page Detection

### URL Pattern Matching

The content script should only activate on repository homepages:

```javascript
// manifest.json content_scripts matches
"matches": ["https://github.com/*/*"]

// Additional filtering in content.js
function isRepoHomepage() {
  const path = window.location.pathname;
  const parts = path.split('/').filter(Boolean);
  
  // Must be exactly /owner/repo (2 parts)
  // Exclude: /owner/repo/issues, /owner/repo/pulls, etc.
  if (parts.length !== 2) return false;
  
  // Exclude special GitHub pages
  const excluded = ['settings', 'marketplace', 'explore', 'topics', 'trending', 'collections'];
  if (excluded.includes(parts[0])) return false;
  
  return true;
}
```

### SPA Navigation Handling

GitHub uses soft navigation (doesn't fully reload page). Must observe for navigation:

```javascript
// Listen for GitHub's Turbo/pjax navigation
document.addEventListener('turbo:render', reinjectButton);
document.addEventListener('pjax:end', reinjectButton);

// Also observe URL changes as fallback
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    reinjectButton();
  }
}).observe(document.body, { childList: true, subtree: true });
```

---

## Edge Cases and Considerations

| Scenario | Handling |
|----------|----------|
| Repo has no releases | Do not inject button |
| Release has no assets (source only) | Show "View Releases" fallback |
| Multiple equally-scored assets | Show dropdown instead of guessing |
| Asset filename has no OS/arch keywords | Lower score, may still match by extension |
| User on unsupported OS (ChromeOS, etc.) | Show dropdown with all assets or "View Releases" |
| Archived repository | Still show button (project may still have valid downloads) |
| Forked repository | Works same as original (has own releases) |
| Very large asset (>1GB) | Show file size in tooltip, warn if >500MB |
| Network offline | Show cached data or hide button gracefully |

---

## File Scaffolds

### manifest.json

```json
{
  "manifest_version": 3,
  "name": "GitHub Easy Download",
  "version": "1.0.0",
  "description": "Adds a one-click download button to GitHub repositories",
  "permissions": [
    "storage"
  ],
  "host_permissions": [
    "https://api.github.com/*"
  ],
  "background": {
    "service_worker": "background.js",
    "type": "module"
  },
  "content_scripts": [
    {
      "matches": ["https://github.com/*/*"],
      "js": ["content.js"],
      "css": ["content.css"],
      "run_at": "document_idle"
    }
  ],
  "action": {
    "default_popup": "popup/popup.html",
    "default_icon": {
      "16": "icons/icon16.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  },
  "options_page": "options/options.html",
  "icons": {
    "16": "icons/icon16.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  }
}
```

### Core Type Definitions (for reference)

```typescript
interface ReleaseData {
  tagName: string;
  name: string;
  publishedAt: string;
  prerelease: boolean;
  assets: Asset[];
  htmlUrl: string;  // Link to releases page
}

interface Asset {
  name: string;
  downloadUrl: string;
  size: number;
  contentType: string;
}

interface MatchResult {
  matched: boolean;
  asset: Asset | null;
  score: number;
  alternatives: Asset[];
  isOldRelease: boolean;
  releaseAgeText: string;  // "6 months ago", "2 years ago"
}

interface UserSystem {
  os: 'windows' | 'macos' | 'linux' | 'unknown';
  arch: 'x64' | 'arm64' | 'x86' | 'unknown';
  raw: {
    platform: string;
    architecture: string;
    userAgent: string;
  };
}

interface ExtensionSettings {
  includePrereleases: boolean;
  showOldReleaseWarning: boolean;
  oldReleaseThresholdDays: number;
  cacheTTLMinutes: number;
}
```

---

## Testing Considerations

### Test Repositories

Use these repos to test various scenarios:

| Scenario | Example Repo |
|----------|--------------|
| Multi-platform releases | `microsoft/vscode`, `obsidianmd/obsidian-releases` |
| Simple single-platform | Various smaller projects |
| No releases | Any repo without releases |
| Only pre-releases | Projects in beta |
| Very old release | Abandoned but useful projects |
| Many assets | Projects with many build variants |

### Manual Test Cases

1. Windows x64 → should match `.exe` or `.msi`
2. macOS Intel → should match `.dmg` with x64
3. macOS Apple Silicon → should prefer arm64/universal, fall back to x64
4. Linux → should match `.AppImage` or `.deb`
5. Repo with no releases → button should not appear
6. Repo with only source releases → should show "View Releases"
7. Rate limited state → should use cache or show fallback
8. Navigate between repos (SPA) → button should update correctly

---

## Future Enhancements (Out of Scope for v1)

- GitHub OAuth for higher rate limits
- Download progress indicator
- Auto-update checking (compare installed vs latest)
- Customizable priority rules per-user
- Support for GitLab, Bitbucket
- Keyboard shortcut for quick download

---

# Claude Code Implementation Prompt

Copy everything below this line to use as context for Claude Code:

---

## CLAUDE CODE CONTEXT

I want to build a Chrome extension called "GitHub Easy Download" that adds a Download button to GitHub repository pages.

### What it does:
- Detects user's OS and CPU architecture using User-Agent Client Hints (with UA string fallback)
- Fetches the latest release from GitHub API: `GET /repos/{owner}/{repo}/releases/latest`
- Uses a scoring algorithm to find the best matching binary asset
- Injects a Download button in TWO locations: (1) next to the green "Code" button in the header, and (2) in the right sidebar near the Releases section
- One-click downloads the matched file, or opens the Releases page if no good match

### Key Technical Decisions:
- Manifest V3 (service worker, not background page)
- Background service worker handles API calls + caching (5-15 min TTL using chrome.storage.local)
- Content script handles DOM injection and UI
- Unauthenticated API only (60 req/hour limit, mitigated by caching)
- Only activates on repo homepage URLs (exactly `github.com/{owner}/{repo}`, not subpages)
- Must handle GitHub's SPA navigation (turbo:render, pjax:end events)

### Asset Matching Priority:

**Windows:** .exe → .msi → .zip (with win/windows in name)
**macOS:** .dmg → .pkg → .zip (with mac/darwin/macos in name)  
**Linux:** .AppImage → .deb → .rpm → .tar.gz

Architecture keywords to match: x64/x86_64/amd64, arm64/aarch64, x86/i386

Use scoring system, not strict priority. Penalize assets that explicitly target different OS/arch.

### UI Requirements:
- Match GitHub's button styling
- Show version in button text: "⬇ Download v1.2.3"
- If release is >1 year old, show subtle warning icon with tooltip
- Dropdown arrow to show alternatives and detected system info
- States: loading, ready, no-match (becomes "View Releases →"), no-releases (hidden), error (hidden)

### Settings (in options page):
- `includePrereleases`: boolean, default false
- `showOldReleaseWarning`: boolean, default true  
- `oldReleaseThresholdDays`: number, default 365
- `cacheTTLMinutes`: number, default 15

Store settings in chrome.storage.sync (syncs across devices).

### File Structure:
```
github-easy-download/
├── manifest.json
├── background.js          # Service worker: API calls, caching
├── content.js             # DOM injection, UI logic
├── content.css            # Styles for injected elements
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
├── options/
│   ├── options.html
│   ├── options.js
│   └── options.css
├── lib/
│   ├── os-detect.js       # detectUserSystem() → {os, arch, raw}
│   ├── asset-matcher.js   # findBestAsset(assets, userSystem) → MatchResult
│   └── github-api.js      # fetchLatestRelease(owner, repo) → ReleaseData
└── icons/
```

### Edge Cases to Handle:
- No releases → hide button
- Only source archives (no binaries) → show "View Releases" fallback
- Rate limited → use stale cache or show fallback
- Archived repos → still show button
- Apple Silicon detection is unreliable → prefer universal/arm64 when available, x64 works via Rosetta
- GitHub SPA navigation → must re-inject button on soft navigation

### Error Handling:
- HTTP 404: No releases or private repo → hide button
- HTTP 403 + rate limit: Use cache → fallback to "View Releases"
- Network error: Use cache → hide button gracefully

Please implement this Chrome extension with clean, well-commented code. Start with the core functionality (OS detection, API fetching, asset matching, button injection) and then add the popup and options pages.
