# GitHub Easy Download Chrome Extension - Project Context

## Project Overview
Chrome extension that adds download buttons to GitHub repository pages. Automatically detects user OS/architecture and matches appropriate release binaries for one-click download.

## Technical Architecture

### Manifest Version
- Manifest V3 (service worker, not background pages)

### Core Components
1. **background.js** - Service worker handling API calls, caching, message passing
2. **content.js** - DOM injection, button creation, OS detection, asset matching
3. **content.css** - Styling for injected buttons
4. **popup/** - Extension popup interface (popup.html, popup.js, popup.css)
5. **options/** - Settings page (options.html, options.js, options.css)

### Key Technical Decisions
- **Button Positioning**: `forceNewRow = true` ensures centered button on own row (better visibility)
- **Cache TTL**: 5-15 minutes default, configurable
- **API**: Unauthenticated GitHub API (60 req/hour limit)
- **OS Detection**: User-Agent Client Hints API with UA string fallback
- **Asset Matching**: Scoring algorithm, not strict priority

## Critical Code Sections

### Button Injection (content.js:583-586)
```javascript
// Always create new row for better visibility and consistent positioning
const forceNewRow = true;

if (forceNewRow || availableSpace < estimatedButtonWidth + 20) {
```
**IMPORTANT**: Keep `forceNewRow = true` for consistent centered positioning

### Button Insertion Location (content.js:616-642)
- Finds `#repo-content-pjax-container`
- Locates navigation bar index
- Inserts full-width container after nav, before file list

### Asset Matching Algorithm (content.js:234-340)
Scoring system considers:
1. File extension match (highest weight: 100 points)
2. OS keyword match (50 points)
3. Architecture match (30 points)
4. Mismatch penalties (negative points)

### Caching Strategy (background.js)
- Uses `chrome.storage.local`
- Key format: `cache_owner/repo`
- Stale-while-revalidate pattern
- Falls back to stale cache if API fails

## GitHub DOM Structure Handling

### Repository Detection (content.js:49-65)
- URL must be exactly `/owner/repo` (no subpaths)
- Excludes: settings, marketplace, explore, topics, trending, collections, orgs, users

### SPA Navigation (content.js:724-742)
Handles GitHub's soft navigation:
- Listens for `turbo:render` events
- Monitors URL changes via MutationObserver
- 1-second delay for re-initialization

### DOM Selectors
**Code Button**:
- `[data-testid="code-button"]`
- `#code-tab`
- `button[aria-label*="Code"]`

**File List**:
- `[aria-labelledby="files"]`
- `[role="grid"]`
- `.js-navigation-container`

**Sidebar Releases**:
- `[class*="BorderGrid"] h2` containing "Release"
- `a[href*="/releases/tag/"]`
- `.Layout-sidebar`

## Platform-Specific Asset Matching

### Windows
1. `.exe` (setup, installer keywords boost score)
2. `.msi`
3. `.zip` (must contain "win" or "windows")

### macOS
1. `.dmg`
2. `.pkg`
3. `.zip` (must contain "mac", "darwin", "macos")
- Special handling for Apple Silicon (prefers universal/arm64, falls back to x64)

### Linux
1. `.AppImage`
2. `.deb`
3. `.rpm`
4. `.tar.gz`, `.tar.xz`

### Architecture Keywords
- **x64**: x64, x86_64, amd64, 64bit
- **ARM64**: arm64, aarch64, apple-silicon, universal
- **x86**: x86, i386, i686, 32bit

## User Settings (options/)

### Storage
- Settings in `chrome.storage.sync` (syncs across devices)
- Cache in `chrome.storage.local` (device-specific)

### Configurable Options
```javascript
{
  includePrereleases: false,
  showOldReleaseWarning: true,
  oldReleaseThresholdDays: 365,
  cacheTTLMinutes: 15
}
```

## API Integration

### Endpoints
- Latest release: `GET /repos/{owner}/{repo}/releases/latest`
- All releases: `GET /repos/{owner}/{repo}/releases` (when includePrereleases=true)

### Rate Limiting
- Unauthenticated: 60 requests/hour
- Check header: `X-RateLimit-Remaining`
- Error handling: Falls back to cached data or "View Releases" button

### Response Transformation (background.js:117-127)
GitHub API response → Internal format:
- tagName, name, publishedAt, prerelease, htmlUrl
- assets[]: name, downloadUrl, size, contentType

## UI/UX Specifications

### Button States
1. **Loading**: Spinner icon, disabled, "Loading..." text
2. **Ready**: Download icon, version text, clickable
3. **No Match**: "View Releases" text, opens releases page
4. **No Releases**: Hidden completely
5. **Old Release**: Warning icon if >365 days old

### Button Placement
1. **Header Button**: Centered on own row below navigation (forceNewRow=true)
2. **Sidebar Button**: Within releases section or About section

### Styling
- Header button: Blue (#0969da), larger when centered
- Sidebar button: Green (#1a7f37), smaller
- Hover effects: Scale transform, shadow changes
- Responsive: Hides text on mobile, shows icon only

## Known Issues & Edge Cases

### Repository-Specific
- **VSCode**: Shows "View Releases" (uses special installer page)
- **Obsidian**: Sidebar button placement varies
- **No releases**: Button hidden entirely
- **Source-only releases**: Shows "View Releases"

### Technical Limitations
- SPA navigation requires delay for DOM updates
- Apple Silicon detection unreliable in some browsers
- Rate limiting requires cache management
- Some repos have non-standard sidebar structures

## Chrome Web Store Requirements

### Required Files
- Icons: 16x16, 48x48, 128x128 PNG
- manifest.json with proper permissions
- Privacy policy

### Permissions Justification
- **storage**: Cache and settings
- **tabs**: Detect current repository
- **host_permissions (api.github.com)**: Fetch release data

### Privacy Compliance
- No data collection
- No external servers (except GitHub API)
- All processing client-side
- No authentication required

## Development Commands

### Testing
```bash
# Load unpacked in Chrome
chrome://extensions/ → Developer mode → Load unpacked

# Create distribution ZIP
zip -r github-easy-download.zip . -x "*.git*" -x "*.DS_Store" -x ".claude/*" -x "STORE_LISTING.md"
```

### Console Debugging
```javascript
// Check if button was injected
document.querySelector('.gh-easy-download-full-width')

// Force scroll to button
document.querySelector('.gh-easy-download-full-width')?.scrollIntoView()

// Check current repo detection
chrome.runtime.sendMessage({action: 'fetchRelease', owner: 'docker', repo: 'compose'}, console.log)
```

## File Structure
```
gh_button/
├── manifest.json
├── background.js (ES6 module)
├── content.js
├── content.css
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
├── options/
│   ├── options.html
│   ├── options.js
│   └── options.css
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── README.md
├── PRIVACY.md
├── STORE_LISTING.md
└── .claude/
    ├── CONTEXT.md (this file)
    └── github-download-button-extension-plan.md (original plan)
```

## Version History
- v1.0.0 - Initial release (December 2024)

## Important Implementation Notes

1. **Never remove `forceNewRow = true`** - This ensures consistent button positioning
2. **Console logs** - Minimal in production, useful for debugging
3. **Button duplication** - Always call `removeInjectedButtons()` before injecting new ones
4. **Cache invalidation** - Automatic via TTL, manual via popup
5. **Error handling** - Graceful degradation to "View Releases" button
6. **Navigation handling** - 500ms-1s delay for GitHub's SPA navigation

## Repository URL
GitHub: `https://github.com/[username]/github-easy-download` (update before publishing)